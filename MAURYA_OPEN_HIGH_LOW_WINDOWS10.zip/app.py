
import streamlit as st
import yfinance as yf
import pandas as pd
from datetime import datetime, time
from zoneinfo import ZoneInfo
import time as time_module

st.set_page_config(page_title="MAURYA OPEN HIGH - OPEN LOW", layout="wide")
st.title("MAURYA OPEN HIGH – OPEN LOW")
st.caption("Free market-data prototype | NSE stocks | 15-minute and 1-hour candles")

# Nifty 50 symbols. Constituents can change; update this list when NSE changes the index.
SYMBOLS = [
    "ADANIENT", "ADANIPORTS", "APOLLOHOSP", "ASIANPAINT", "AXISBANK",
    "BAJAJ-AUTO", "BAJFINANCE", "BAJAJFINSV", "BEL", "BHARTIARTL",
    "CIPLA", "COALINDIA", "DRREDDY", "EICHERMOT", "ETERNAL",
    "GRASIM", "HCLTECH", "HDFCBANK", "HDFCLIFE", "HEROMOTOCO",
    "HINDALCO", "HINDUNILVR", "ICICIBANK", "INDUSINDBK", "INFY",
    "ITC", "JIOFIN", "JSWSTEEL", "KOTAKBANK", "LT",
    "M&M", "MARUTI", "NESTLEIND", "NTPC", "ONGC",
    "POWERGRID", "RELIANCE", "SBILIFE", "SBIN", "SHRIRAMFIN",
    "SUNPHARMA", "TATACONSUM", "TATASTEEL", "TCS", "TECHM",
    "TITAN", "TRENT", "ULTRACEMCO", "WIPRO", "MAXHEALTH"
]
TICKERS = [s + ".NS" for s in SYMBOLS]
IST = ZoneInfo("Asia/Kolkata")

st.warning(
    "महत्वपूर्ण: यह Yahoo Finance के मुफ्त डेटा पर आधारित है। डेटा delayed, अधूरा या कभी-कभी unavailable हो सकता है। "
    "यह आधिकारिक NSE real-time feed नहीं है। ट्रेड लेने से पहले अपने broker/chart पर भाव verify करें।"
)

with st.sidebar:
    st.header("Settings")
    timeframe = st.radio("Timeframe", ["15 मिनट", "1 घंटा"], horizontal=False)
    refresh = st.selectbox("Auto refresh", ["Manual", "1 minute", "5 minutes"], index=2)
    st.caption("गिनती केवल सबसे नई उपलब्ध पूरी candle पर की जाती है।")

interval = "15m" if timeframe == "15 मिनट" else "60m"
period = "5d" if interval == "15m" else "1mo"

@st.cache_data(ttl=60)
def get_market_data(interval, period):
    # Batch request reduces the number of separate calls.
    raw = yf.download(
        tickers=TICKERS,
        period=period,
        interval=interval,
        group_by="ticker",
        auto_adjust=False,
        progress=False,
        threads=True
    )
    return raw

def extract_ticker_frame(raw, ticker):
    if raw is None or raw.empty:
        return pd.DataFrame()
    try:
        if isinstance(raw.columns, pd.MultiIndex):
            if ticker in raw.columns.get_level_values(0):
                df = raw[ticker].copy()
            elif ticker in raw.columns.get_level_values(1):
                df = raw.xs(ticker, axis=1, level=1).copy()
            else:
                return pd.DataFrame()
        else:
            df = raw.copy()
        df = df.dropna(subset=["Open", "High", "Low", "Close"])
        return df
    except Exception:
        return pd.DataFrame()

def last_completed_bar(df, interval):
    if df.empty:
        return None, None
    now = datetime.now(IST)
    duration_minutes = 15 if interval == "15m" else 60
    # Yahoo timestamps are normally timezone-aware; normalize to IST.
    idx = pd.DatetimeIndex(df.index)
    if idx.tz is None:
        idx = idx.tz_localize("UTC").tz_convert(IST)
    else:
        idx = idx.tz_convert(IST)
    temp = df.copy()
    temp.index = idx
    # Keep only bars whose scheduled end time has passed.
    completed = temp[temp.index + pd.Timedelta(minutes=duration_minutes) <= pd.Timestamp(now)]
    if completed.empty:
        return None, None
    return completed.iloc[-1], completed.index[-1]

def classify(row):
    o, h, l = float(row["Open"]), float(row["High"]), float(row["Low"])
    # Small floating-point tolerance; prices are checked to the nearest paise.
    if abs(o - h) <= 0.005:
        return "Open = High"
    if abs(o - l) <= 0.005:
        return "Open = Low"
    return "Neither"

if refresh != "Manual":
    seconds = 60 if refresh == "1 minute" else 300
    st.info(f"Auto refresh: every {seconds} seconds. Keep this page open.")
    st.markdown(f"<meta http-equiv='refresh' content='{seconds}'>", unsafe_allow_html=True)

if st.button("Refresh data now"):
    st.cache_data.clear()
    st.rerun()

with st.spinner("50 शेयरों का डेटा लोड हो रहा है... इसमें कुछ समय लग सकता है।"):
    try:
        raw = get_market_data(interval, period)
    except Exception as e:
        st.error(f"डेटा नहीं मिला: {e}")
        st.stop()

rows = []
for symbol, ticker in zip(SYMBOLS, TICKERS):
    df = extract_ticker_frame(raw, ticker)
    bar, stamp = last_completed_bar(df, interval)
    if bar is None:
        rows.append({"Stock": symbol, "Status": "Data unavailable", "Candle time": "-",
                     "Open": None, "High": None, "Low": None, "Close": None})
    else:
        rows.append({"Stock": symbol, "Status": classify(bar), "Candle time": stamp.strftime("%d-%b %H:%M"),
                     "Open": round(float(bar["Open"]), 2), "High": round(float(bar["High"]), 2),
                     "Low": round(float(bar["Low"]), 2), "Close": round(float(bar["Close"]), 2)})

result = pd.DataFrame(rows)
valid = result[result["Status"] != "Data unavailable"]
open_high = int((valid["Status"] == "Open = High").sum())
open_low = int((valid["Status"] == "Open = Low").sum())
neither = int((valid["Status"] == "Neither").sum())
total = len(valid)

c1, c2, c3, c4 = st.columns(4)
c1.metric("Open = Low (Bullish bias)", open_low, f"{(open_low/total*100):.1f}%" if total else "—")
c2.metric("Open = High (Bearish bias)", open_high, f"{(open_high/total*100):.1f}%" if total else "—")
c3.metric("Neither", neither)
c4.metric("Data received", f"{total}/50")

if total:
    if open_low > open_high:
        st.success("इस sample में Open = Low वाले शेयर ज्यादा हैं — bullish bias हो सकता है, पक्का buy signal नहीं।")
    elif open_high > open_low:
        st.error("इस sample में Open = High वाले शेयर ज्यादा हैं — bearish bias हो सकता है, पक्का sell signal नहीं।")
    else:
        st.info("Open = Low और Open = High बराबर हैं — mixed signal।")

st.subheader(f"{timeframe} – सभी शेयर")
st.dataframe(result, use_container_width=True, hide_index=True)
st.download_button("Download CSV", result.to_csv(index=False).encode("utf-8"), "maurya_open_high_low.csv", "text/csv")

st.caption(
    "ध्यान दें: Open=Low / Open=High केवल candle की स्थिति बताता है। "
    "यह अकेले बाजार की दिशा या अगली चाल की गारंटी नहीं देता। Nifty 50 की सूची समय-समय पर बदलती है।"
)
