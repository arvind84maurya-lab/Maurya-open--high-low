MAURYA OPEN HIGH – OPEN LOW (Windows 10)

INSTALL:
1. Install Python 3.11 or newer from https://www.python.org/downloads/windows/
2. During installation, tick "Add Python to PATH".
3. Extract this ZIP folder.
4. Double-click START_DASHBOARD.bat.
5. A browser tab will open with the dashboard.

MOBILE:
- Laptop and phone should be connected to the same Wi-Fi.
- When Streamlit starts, it normally shows a local URL.
- For phone access, start the app with:
  py -m streamlit run app.py --server.address 0.0.0.0
- Find the laptop's local IPv4 address using Windows Command Prompt: ipconfig
- On the phone browser, open http://LAPTOP-IP:8501
- Windows Firewall may ask permission; allow on Private networks only.

IMPORTANT:
- Uses Yahoo Finance free data through yfinance. It is not an official NSE feed.
- Data may be delayed, incomplete, rate-limited, or unavailable. No guaranteed real-time data.
- Verify all prices on your broker before trading.
- Candle classification is based on the latest fully completed available candle.
- The Nifty 50 list is a maintained snapshot and may need updating after index changes.
